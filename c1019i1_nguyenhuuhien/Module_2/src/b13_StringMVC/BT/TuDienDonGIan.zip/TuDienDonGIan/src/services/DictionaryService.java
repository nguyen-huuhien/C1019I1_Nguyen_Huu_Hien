package services;

public interface DictionaryService {
    String findByEnglish(String eng);
}

package com.thymeleaf.quanlykhachhangspringbootthymeleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanlykhachhangspringbootthymeleafApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuanlykhachhangspringbootthymeleafApplication.class, args);
    }

}

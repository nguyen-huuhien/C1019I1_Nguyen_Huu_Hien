package com.thymeleaf.quanlykhachhangspringbootthymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanlykhachhangspringbootthymeleafApplicationTests {

    @Test
    void contextLoads() {
    }

}

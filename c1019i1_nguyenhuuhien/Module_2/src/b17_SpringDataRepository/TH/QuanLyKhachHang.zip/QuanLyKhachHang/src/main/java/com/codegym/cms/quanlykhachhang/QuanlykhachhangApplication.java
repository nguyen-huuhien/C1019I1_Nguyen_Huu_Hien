package com.codegym.cms.quanlykhachhang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuanlykhachhangApplication {

    public static void main(String[] args) {
        SpringApplication.run(QuanlykhachhangApplication.class, args);
    }

}
